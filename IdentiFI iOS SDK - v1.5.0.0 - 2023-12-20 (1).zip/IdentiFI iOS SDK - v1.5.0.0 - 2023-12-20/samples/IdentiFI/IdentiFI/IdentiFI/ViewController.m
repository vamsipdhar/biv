//
//  ViewController.m
//  IdentiFI Sample
//
//  Copyright © 2015 - 2023 S.I.C. Biometrics . All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

id myIdentiFI_Device;
BOOL isFpCapture = NO;


-(void) enableUI: (BOOL) lockStatus
{
    self.connect.enabled = lockStatus;
    self.disconnect.enabled = lockStatus;
    self.getBatteryLevel.enabled = lockStatus;
    self.getDeviceSerialNumber.enabled = lockStatus;
    self.getFirmwareVersion.enabled = lockStatus;
    self.startFirmwareUpdate.enabled = lockStatus;
    self.getLibraryVersion.enabled = lockStatus;
    self.getModelNumber.enabled = lockStatus;
    self.getReaderDescription.enabled = lockStatus;
    self.setMinNFIQScore.enabled = lockStatus;
    self.startCaptureOneFinger.enabled = lockStatus;
    self.startCaptureTwoFinger.enabled = lockStatus;
    self.startCaptureFourFinger.enabled = lockStatus;
    self.startCaptureRollFinger.enabled = lockStatus;
    self.setFpPowerOn.enabled = lockStatus;
    self.setFpPowerOff.enabled = lockStatus;
    self.getFpPowerStatus.enabled = lockStatus;
    self.isFingerDuplicated.enabled = lockStatus;
    self.getSavedWSQFpImage.enabled = lockStatus;
    self.getSavedFpNFIQScore.enabled = lockStatus;
    self.getSavedSegmentedFpImage.enabled = lockStatus;
    self.clearSavedFpImages.enabled = lockStatus;
    self.startCaptureIris.enabled = lockStatus;
    self.setLEDBrightness.enabled = lockStatus;
    self.setLEDControl.enabled = lockStatus;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    _linkStatus.text = @"Disconnected";
    myIdentiFI_Device = [[IdentiFI alloc] init];
    [myIdentiFI_Device setDelegate:self];
}

- (IBAction)steppersavedAtIndex:(UIStepper *)sender {
    self.savedAtIndexInput_TF.text = [NSString stringWithFormat:@"%d", (int) sender.value];
}

- (IBAction)getIrisPowerStatus:(id)sender {
    _commandResponse.text = @"Getting iris power status ...";
    [myIdentiFI_Device getIrisPowerStatus];
}

- (void) onGetIrisPowerStatus:(Boolean) irisPowerStatus
{
    if(irisPowerStatus)
        _commandResponse.text = @"Iris sensor power is On.";
    else
        _commandResponse.text = @"Iris sensor power is Off.";
}

- (IBAction)setIrisPowerOff:(id)sender {
    _commandResponse.text = @"Powering off iris sensor...";
    [myIdentiFI_Device setIrisPowerOff];
}

- (void) onSetIrisPowerOff
{
    _commandResponse.text = @"Set iris sensor power to Off.";
}

- (IBAction)setIrisPowerOn:(id)sender {
    _commandResponse.text = @"Setting iris sensor power to On...";
    [myIdentiFI_Device setIrisPowerOn];
}

- (void) onSetIrisPowerOn:(Boolean) irisPowerStatus
{
    if(irisPowerStatus)
        _commandResponse.text = @"Set iris sensor power to On succeeded.";
    else
        _commandResponse.text = @"Failed to power and wake up iris sensor.";
}


- (IBAction)connect:(id)sender
{
    _linkStatus.text = @"Connecting ...";
    _commandResponse.text = @"";
    [myIdentiFI_Device connect];

}
- (void) onConnection
{
    _linkStatus.text = @"Connected";
    _commandResponse.text = @"";
}

- (void) onConnectionTimeOut
{
    _linkStatus.text = @"Connection time out.";
}

- (void) onConnectionError:(NSString *) errorDescription
{
    _linkStatus.text = @"Connection Error.";
    _commandResponse.text = errorDescription;
}

- (IBAction) disconnect:(id)sender
{
    _linkStatus.text = @"Disconnecting ...";
    _commandResponse.text = @"";
    _userInstruction.text = @"";
    [myIdentiFI_Device disconnect];
    [self enableUI: YES];
}
- (void) onDisconnection
{
    _linkStatus.text = @"Disconnected";
}

- (IBAction)getBatteryLevel:(id)sender
{
    _commandResponse.text = @"";
    [myIdentiFI_Device getBatteryPercentage];
}
- (void) onGetBatteryPercentage:(int) percentLevel
{
    _commandResponse.text = [NSString stringWithFormat:@"Battery: %d %% ",percentLevel];
}

- (IBAction)getModelNumber:(id)sender
{
    _commandResponse.text = @"";
    [myIdentiFI_Device getModelNumber];
}
- (void) onGetModelNumber:(NSString *) model
{
    _commandResponse.text = [NSString stringWithFormat:@"Model: %@",model];
}

- (IBAction)getDeviceSerialNumber:(id)sender
{
    _commandResponse.text = @"";
    [myIdentiFI_Device getDeviceSerialNumber];
}
- (void) onGetDeviceSerialNumber:(NSString*) serialNumber
{
    _commandResponse.text = [NSString stringWithFormat:@"S/N: %@",serialNumber];
}

- (IBAction)getReaderDescription:(id)sender
{
    _commandResponse.text = @"";
    [myIdentiFI_Device getReaderDescription];
}
- (void) onGetReaderDescription:(NSString *) deviceDescription
{
    _commandResponse.text = [NSString stringWithFormat:@"Reader Description: %@",deviceDescription];
}

- (IBAction)getFirmwareVersion:(id)sender
{
    _commandResponse.text = @"";
    [myIdentiFI_Device getFirmwareVersion];
}
- (void) onGetFirmwareVersion:(NSString *) firmwareVersion
{
    _commandResponse.text = [NSString stringWithFormat:@"FW: %@", firmwareVersion];
}

- (IBAction)getLibraryVersion:(id)sender
{
    _commandResponse.text = [NSString stringWithFormat:@"Library: %@", [myIdentiFI_Device getLibraryVersion]];
}

- (IBAction)setFpPowerOn:(id)sender {
    _commandResponse.text = @"Setting fingerprint sensor power to On...";
    [myIdentiFI_Device setFpPowerOn];
}
- (void) onSetFpPowerOn:(Boolean) fpPowerStatus
{
    if(fpPowerStatus)
        _commandResponse.text = @"Set fingerprint sensor power to On succeeded.";
    else
        _commandResponse.text = @"Failed to power and wake up FP sensor.";
}

- (IBAction)setFpPowerOff:(id)sender
{
    _commandResponse.text = @"Powering OFF fingerprint sensor...";
    [myIdentiFI_Device setFpPowerOff];
}
- (void) onSetFpPowerOff
{
    _commandResponse.text = @"Set fingerprint sensor power to Off.";
}

- (IBAction)getFpPowerStatus:(id)sender {
    _commandResponse.text = @"Getting Fp Power Status ...";
    [myIdentiFI_Device getFpPowerStatus];
}
- (void) onGetFpPowerStatus:(Boolean) fpPowerStatus
{
    if(fpPowerStatus)
        _commandResponse.text = @"Fingerprint sensor power is On.";
    else
        _commandResponse.text = @"Fingerprint sensor power is Off.";
}

- (IBAction)startCaptureOneFinger:(id)sender
{
    isFpCapture = YES;
    _commandResponse.text = [NSString stringWithFormat:(@"Finger capture to be saved at index: %@."),[self.savedAtIndexInput_TF text]] ;
    _userInstruction.text = @"Place one finger on the sensor";

    [myIdentiFI_Device startCaptureOneFinger:[[self.savedAtIndexInput_TF text] intValue] ];
    self.greenLED.hidden = TRUE;
    [self enableUI: NO];
}

- (IBAction)startCaptureTwoFinger:(id)sender
{
    isFpCapture = YES;
    _commandResponse.text = [NSString stringWithFormat:(@"Fingers capture to be saved at index: %@."),[self.savedAtIndexInput_TF text]] ;
    _userInstruction.text = @"Place two finger on the sensor";

    [myIdentiFI_Device startCaptureTwoFinger:[[self.savedAtIndexInput_TF text] intValue] ];
    self.greenLED.hidden = TRUE;
    [self enableUI: NO];
}

- (IBAction)startCaptureFourFinger:(id)sender {
    isFpCapture = YES;
    _commandResponse.text = [NSString stringWithFormat:(@"Fingers capture to be saved at index: %@."),[self.savedAtIndexInput_TF text]] ;
    _userInstruction.text = @"Place four finger on the sensor";
    [myIdentiFI_Device startCaptureFourFinger:[[self.savedAtIndexInput_TF text] intValue] ];
    self.greenLED.hidden = TRUE;
    [self enableUI: NO];
}

- (IBAction)startCaptureRollFinger:(id)sender
{
    isFpCapture = YES;
    _commandResponse.text = [NSString stringWithFormat:(@"Fingers capture to be saved at index: %@."),[self.savedAtIndexInput_TF text]] ;
    _userInstruction.text = @"Roll one finger on the sensor";
    [myIdentiFI_Device startCaptureRollFinger:[[self.savedAtIndexInput_TF text] intValue] ];
    self.greenLED.hidden = TRUE;
    [self enableUI: NO];
}

- (void) onStreaming:(UIImage *) fpImage
{
    if(self.fpImage.hidden == TRUE)
    {
        self.viewIrisImages.hidden = TRUE;
        self.fpImage.hidden = FALSE;
    }
    
    if((fpImage.size.width == 200) && (self.fpImage.frame.size.width != 200)) //IdentiFI-30
    {
        CGRect fpImageFrame;
        fpImageFrame.origin.x = 284;
        fpImageFrame.origin.y = 600;
        fpImageFrame.size.width = 200;
        fpImageFrame.size.height = 250;
        self.fpImage.frame = fpImageFrame;
    }
    else if((fpImage.size.width == 400) && (self.fpImage.frame.size.width != 400)) //IdentiFI-45
    {
        CGRect fpImageFrame;
        fpImageFrame.origin.x = 185;
        fpImageFrame.origin.y = 530;
        fpImageFrame.size.width = 400;
        fpImageFrame.size.height = 375;
        self.fpImage.frame = fpImageFrame;
    }
    else if((fpImage.size.width == 800) && (fpImage.size.height == 500) && (self.fpImage.frame.size.width != 700)) //IdentiFI-50
    {
        CGRect fpImageFrame;
        fpImageFrame.origin.x = 34;
        fpImageFrame.origin.y = 515;
        fpImageFrame.size.width = 700;
        fpImageFrame.size.height = 438;
        self.fpImage.frame = fpImageFrame;
    }
    else if((fpImage.size.width == 800) && (self.fpImage.frame.size.width != 700) ) //IdentiFI-60
    {
        CGRect fpImageFrame;
        fpImageFrame.origin.x = 140;
        fpImageFrame.origin.y = 485;
        fpImageFrame.size.width = 550;
        fpImageFrame.size.height = 510;
        self.fpImage.frame = fpImageFrame;
    }

    self.fpImage.image = fpImage;
    self.greenLED.hidden = !self.greenLED.hidden;

}


- (void) onStreamingRolledFp:(UIImage *) fpImage rollingState:(int) currentRollingState verticalLineX:(int) currentXPosition
{
    if(self.fpImage.hidden == TRUE)
    {
        self.viewIrisImages.hidden = TRUE;
        self.fpImage.hidden = FALSE;
    }
    
    if (self.fpImage.frame.size.width != 400)
    {
        CGRect fpImageFrame;
        fpImageFrame.origin.x = 185;
        fpImageFrame.origin.y = 530;
        fpImageFrame.size.height = 375;
        fpImageFrame.size.width = 400;
        self.fpImage.frame = fpImageFrame;
    }

    switch (currentRollingState)
    {
        case 0: //FINGER NOT YET DETECTED
            self.fpImage.image = fpImage;
            break;
        case 1: //BEGIN ROLLING
            self.fpImage.image = [self drawVerticalLineOn:fpImage atX:currentXPosition withColor: UIColor.redColor];
            break;
        case 2: //KEEP ROLLING
            self.fpImage.image = [self drawVerticalLineOn:fpImage atX:currentXPosition withColor: UIColor.greenColor];
            break;
        default: //Should not get here.
            self.fpImage.image = fpImage;
            break;
    }

    self.greenLED.hidden = !self.greenLED.hidden;

}

- (UIImage *) drawVerticalLineOn:(UIImage*) targetImage atX:(int) xPosition withColor:(UIColor *) lineColor
{
    UIGraphicsBeginImageContext(targetImage.size);

    [targetImage drawAtPoint:CGPointMake(0,0)];

    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(context,1.0);
    CGContextMoveToPoint(context, xPosition, 0);
    CGContextAddLineToPoint(context, xPosition, targetImage.size.height);
    CGContextSetStrokeColorWithColor(context, [lineColor CGColor]);
    CGContextStrokePath(context);

    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();

    UIGraphicsEndImageContext();

    return newImage;
}

- (void) onLastFrame:(UIImage *) fpImage fpImageSavedAt:(int)savedAtIndex
{
    _userInstruction.text = [NSString stringWithFormat:@"Capture of fp # %d completed.",savedAtIndex];

    //Remove comment to display image from received UIImage *, otherwise, use below onLastFrame_RAW callback to display final image
    //self.fpImage.image = fpImage;
    self.greenLED.hidden = TRUE;

    [self enableUI: YES];

}

- (void) onLastFrame_RAW:(NSData *) rawFpImageData fpImageSavedAt:(int)savedAtIndex
{
    _commandResponse.text=[NSString stringWithFormat:(@"rawFpImage size: %lu bytes, saved in IdentiFI at index: %u"),(unsigned long)rawFpImageData.length,savedAtIndex] ;

    CFDataRef imgData = (__bridge CFDataRef)rawFpImageData;
    CGDataProviderRef imgDataProvider = CGDataProviderCreateWithCFData (imgData);
    CGColorSpaceRef space = CGColorSpaceCreateDeviceGray();
    CGImageRef fpCapturedImage = NULL;
    if (rawFpImageData.length == 200000)
    {
        fpCapturedImage = CGImageCreate(400,                            // width
                                        500,                            // height
                                        8,                              // bitsPerComponent
                                        8,                              // bitsPerPixel
                                        400,                            // bytesPerRow
                                        space,                          // colorspace
                                        kCGBitmapByteOrderDefault,      // bitmapInfo
                                        imgDataProvider,                // CGDataProvider
                                        NULL,                           // decode array
                                        NO,                             // shouldInterpolate
                                        kCGRenderingIntentDefault);     // intent
    }
    else if (rawFpImageData.length == 600000)
    {
        fpCapturedImage = CGImageCreate(800,                            // width
                                        750,                            // height
                                        8,                              // bitsPerComponent
                                        8,                              // bitsPerPixel
                                        800,                            // bytesPerRow
                                        space,                          // colorspace
                                        kCGBitmapByteOrderDefault,      // bitmapInfo
                                        imgDataProvider,                // CGDataProvider
                                        NULL,                           // decode array
                                        NO,                             // shouldInterpolate
                                        kCGRenderingIntentDefault);     // intent
    }
    else if (rawFpImageData.length == 1600000)
    {
        fpCapturedImage = CGImageCreate(1600,                           // width
                                        1000,                           // height
                                        8,                              // bitsPerComponent
                                        8,                              // bitsPerPixel
                                        1600,                           // bytesPerRow
                                        space,                          // colorspace
                                        kCGBitmapByteOrderDefault,      // bitmapInfo
                                        imgDataProvider,                // CGDataProvider
                                        NULL,                           // decode array
                                        NO,                             // shouldInterpolate
                                        kCGRenderingIntentDefault);     // intent
    }else if (rawFpImageData.length == 2400000)
    {
        fpCapturedImage = CGImageCreate(1600,                           // width
                                        1500,                           // height
                                        8,                              // bitsPerComponent
                                        8,                              // bitsPerPixel
                                        1600,                           // bytesPerRow
                                        space,                          // colorspace
                                        kCGBitmapByteOrderDefault,      // bitmapInfo
                                        imgDataProvider,                // CGDataProvider
                                        NULL,                           // decode array
                                        NO,                             // shouldInterpolate
                                        kCGRenderingIntentDefault);     // intent
    }
    CGColorSpaceRelease(space);
    CGDataProviderRelease(imgDataProvider);
    self.fpImage.image = [UIImage imageWithCGImage:fpCapturedImage scale:1 orientation:(UIImageOrientationDownMirrored)];
    CGImageRelease(fpCapturedImage);
    [self enableUI: YES];

}

- (void) onLastFrameRolledFp:(UIImage *) fpImage fpImageSavedAt:(int)savedAtIndex
{
    //Remove comment to display image from received UIImage *, otherwise, use below onLastFrameRolledFp_RAW callback to display final image
    //self.fpImage.image = fpImage;
    self.greenLED.hidden = TRUE;
    [self enableUI: YES];
}

- (void) onLastFrameRolledFp_RAW:(NSData *) rawFpImageData fpImageSavedAt:(int)savedAtIndex
{
    _commandResponse.text=[NSString stringWithFormat:(@"rawFpImage size: %lu bytes, saved in IdentiFI at index: %u"),(unsigned long)rawFpImageData.length,savedAtIndex] ;

    CFDataRef imgData = (__bridge CFDataRef)rawFpImageData;
    CGDataProviderRef imgDataProvider = CGDataProviderCreateWithCFData (imgData);
    CGColorSpaceRef space = CGColorSpaceCreateDeviceGray();
    CGImageRef fpCapturedImage = CGImageCreate(800,                        // width
                                               750,                        // height
                                               8,                          // bitsPerComponent
                                               8,                          // bitsPerPixel
                                               800,                        // bytesPerRow
                                               space,                      // colorspace
                                               kCGBitmapByteOrderDefault,  // bitmapInfo
                                               imgDataProvider,            // CGDataProvider
                                               NULL,                       // decode array
                                               NO,                         // shouldInterpolate
                                               kCGRenderingIntentDefault); // intent
    
    CGColorSpaceRelease(space);
    CGDataProviderRelease(imgDataProvider);
    self.fpImage.image = [UIImage imageWithCGImage:fpCapturedImage scale:1 orientation:(UIImageOrientationDownMirrored)];
    CGImageRelease(fpCapturedImage);
    [self enableUI: YES];
}

- (IBAction)startCaptureIris:(id)sender {
    _userInstruction.text = @"Starting Iris capture...";
    _commandResponse.text = @"";
    isFpCapture = NO;
    [myIdentiFI_Device startCaptureIris];
    [self enableUI: NO];
}

- (void) onStreamingLeftIris:(UIImage *) leftIrisImage RightIris:(UIImage *) rightIrisImage
{
    if(self.viewIrisImages.isHidden)
    {
        self.viewIrisImages.hidden = FALSE;
        self.fpImage.hidden = TRUE;
    }

    self.rightUserIrisImage.image = rightIrisImage;
    self.leftUserIrisImage.image = leftIrisImage;
    self.greenLED.hidden = !self.greenLED.hidden;
}

- (void) onIrisCaptureStatus:(unsigned int) irisCaptureStatus
{
    switch (irisCaptureStatus) {
        case 1:
            _userInstruction.text = @"Capture will begin...";
            break;
        case 2:
            _userInstruction.text = @"Eyes are detected! Keep moving.";
            break;
        case 3:
            _userInstruction.text = @"Capture completed";
            break;
        case 5:
            _userInstruction.text = @"Capture Aborted error, Iris sensor capture stopped and powered off.";
            _commandResponse.text = @"";
            [self enableUI: YES];
            break;
        case 9:
            _userInstruction.text = @"Failed to start Iris capture, Iris sensor not powered";
            _commandResponse.text = @"";
            [self enableUI: YES];
            break;
        default:
            _commandResponse.text=[NSString stringWithFormat:(@"Unknown status/error code: %d "), irisCaptureStatus];
            break;
    }
}

- (void) onLastFrameLeftIris:(UIImage *) leftIrisImage RightIris:(UIImage *) rightIrisImage  LeftIrisTotalScore:(int) LTS LeftIrisUsableArea:(int) LUA RightIrisTotalScore:(int) RTS RightIrisUsableArea:(int) RUA;
{
    self.rightUserIrisImage.image = rightIrisImage;
    self.leftUserIrisImage.image = leftIrisImage;
    _commandResponse.text =  [NSString stringWithFormat:(@"Iris Capture results: LeftTotalScore:%d LeftUsableArea:%d RightTotalScore:%d  RightUsableArea:%d "),LTS, LUA, RTS, RUA];
    self.greenLED.hidden = !self.greenLED.hidden;
    [self enableUI: YES];
}

- (IBAction)cancelCapture:(id)sender
{
    _userInstruction.text = @"Cancelling capture ...";
    if(isFpCapture)
    {
        [myIdentiFI_Device cancelFpCapture];
    }
    else
    {
        [myIdentiFI_Device cancelIrisCapture];
    }
    self.greenLED.hidden = TRUE;
    [self enableUI: YES];
}

- (void) onCancelFpCapture
{
    _userInstruction.text = @"Fingerpring capture canceled by user.";
    self.fpImage.hidden = TRUE;
}

- (void) onCancelIrisCapture
{
    _userInstruction.text = @"Iris capture canceled by user.";
    self.viewIrisImages.hidden = TRUE;
}

- (IBAction)setMinNFIQScore:(id)sender {
    [myIdentiFI_Device setMinimumNFIQScore:[ [self.minimumNFIQScore_TF text] intValue] ];
}

- (void) onSetMinimumNFIQScore:(int) newMinimumNFIQScore
{
    _commandResponse.text = [NSString stringWithFormat:(@"Set minimum NFIQ score to %d"), newMinimumNFIQScore];
}

- (void) onFpCaptureStatus: (int) fpCaptureStatus
{

    NSDateFormatter *dF = [[NSDateFormatter alloc] init];
    [dF setDateFormat:@"hh:mm:ss"];
    NSString *currentTime = [dF stringFromDate:[NSDate date]];

    switch (fpCaptureStatus)
    {
        case 1:
            _commandResponse.text =  [NSString stringWithFormat:@"Finger capture didn't meet minimum NFIQ score at %@", currentTime];
            break;
        case 9:
            _userInstruction.text = @"Failed to start FP capture, FP sensor not powered.";
            _commandResponse.text = @"";
            [self enableUI: YES];
            break;
        case 304:
            _userInstruction.text = [NSString stringWithFormat:@"Rolling smear detected at %@", currentTime];
            break;
        case 305:
            _userInstruction.text = [NSString stringWithFormat:@"Rolled finger was shifted horizontally at %@", currentTime];
            break;
        case 306:
            _userInstruction.text = [NSString stringWithFormat:@"Rolled finger was shifted vertically at %@", currentTime];
            break;
        case 307:
            _userInstruction.text = [NSString stringWithFormat:@"Rolled finger was shifted both horizontally and vertically at %@", currentTime];
            break;
        case -600:
            _commandResponse.text=[NSString stringWithFormat:(@"Failed to extract details for duplicate at %@"), currentTime];
            break;
        default:
            _commandResponse.text=[NSString stringWithFormat:(@"Unknown status/error code: %d at %@"), fpCaptureStatus, currentTime];
            break;
    }
}

- (IBAction)isFingerDuplicated:(id)sender
{
    _commandResponse.text=[NSString stringWithFormat:(@"Checking finger saved at index = %d for duplicate"),[[self.savedAtIndexInput_TF text] intValue]];
    [myIdentiFI_Device isFingerDuplicated: [[self.savedAtIndexInput_TF text] intValue] securityLevel: [[self.securityLevel_TF text] intValue] ];
}

- (void) onIsFingerDuplicated:(int) isFingerDuplicated;
{
    switch (isFingerDuplicated)
    {
        case -1:
            _commandResponse.text=@"No finger saved at this index.";
            break;
        case 0:
            _commandResponse.text=@"Finger is not a duplicate.";
            break;
        case 1:
            _commandResponse.text=@"Finger is a duplicate.";
            break;
    }
}

- (IBAction)getSavedWSQFpImage:(id)sender {

    _commandResponse.text = [NSString stringWithFormat:(@"Retrieving WSQ image saved at index: %@."),[self.savedAtIndexInput_TF text]] ;

    [myIdentiFI_Device getWSQEncodedFpImageFromImageSavedAt:[[self.savedAtIndexInput_TF text] intValue] croppedImage:true];
}

-(void) onGetWSQEncodedFpImage:(NSData *) wsqEncodedFpImageData fromImageSavedAt: (int) savedAtIndex
{
    NSString *documentsDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];

    NSString *wsqImageFilePath = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"WSQ_FP_Image_%d.wsq",savedAtIndex]];

    [wsqEncodedFpImageData writeToFile:wsqImageFilePath atomically:YES ];

    _commandResponse.text = [NSString stringWithFormat:(@"Saved WSQ(index=%d) to file: WSQ_FP_Image_%d.wsq(%lu bytes)"),savedAtIndex,savedAtIndex, (unsigned long)[wsqEncodedFpImageData length]];
}

- (IBAction)getSavedFpNFIQScore:(id)sender {
    _commandResponse.text = [NSString stringWithFormat:(@"Retrieving NFIQ score from image saved at index: %@."),[self.savedAtIndexInput_TF text]];
    [myIdentiFI_Device getNfiqScoreFromImageSavedAt:[[self.savedAtIndexInput_TF text] intValue]];
}

- (void) onGetNfiqScore:(int) nfiqScore fromImageSavedAt: (int) savedAtIndex;
{
    _commandResponse.text=[NSString stringWithFormat:(@"NFIQ Score = %u (from fp image saved at index: %u)"), nfiqScore,savedAtIndex] ;
}

- (IBAction)getSavedSegmentedFpImage:(id)sender {
    _commandResponse.text = @"Retrieving saved Segmented Fp Image ...";
    [myIdentiFI_Device getSegmentedFpImageSavedAt:[[self.savedAtIndexInput_TF text] intValue]];
}

- (void) onGetSegmentedFpImage_RAW:(NSData *) rawFpImageData fromImageSavedAt:(int)savedAtIndex
{
    _userInstruction.text = @"";
    _commandResponse.text=[NSString stringWithFormat:(@"rawFpImage size: %lu bytes, saved in IdentiFI at index: %u"),(unsigned long)rawFpImageData.length,savedAtIndex] ;

    CGRect fpImageFrame;
    fpImageFrame.origin.x = 185;
    fpImageFrame.origin.y = 530;
    fpImageFrame.size.width = 400;
    fpImageFrame.size.height = 375;
    self.fpImage.frame = fpImageFrame;

    CFDataRef imgData = (__bridge CFDataRef)rawFpImageData;
    CGDataProviderRef imgDataProvider = CGDataProviderCreateWithCFData (imgData);
    CGColorSpaceRef space = CGColorSpaceCreateDeviceGray();
    CGImageRef fpCapturedImage = CGImageCreate(800, // width
                                               750, // height
                                               8,                                           // bitsPerComponent
                                               8,                                           // bitsPerPixel
                                               800, // bytesPerRow
                                               space,                                       // colorspace
                                               kCGBitmapByteOrderDefault,                   // bitmapInfo
                                               imgDataProvider,                             // CGDataProvider
                                               NULL,                                        // decode array
                                               NO,                                          // shouldInterpolate
                                               kCGRenderingIntentDefault);                  // intent
    CGColorSpaceRelease(space);
    CGDataProviderRelease(imgDataProvider);
    self.fpImage.image = [UIImage imageWithCGImage:fpCapturedImage scale:1 orientation:(UIImageOrientationDownMirrored)];
    CGImageRelease(fpCapturedImage);
}

- (IBAction)clearSavedFpImages:(id)sender {
    _commandResponse.text = @"Clearing saved fingerprint images from IdentiFI memory";
    [myIdentiFI_Device clearSavedFpImages:[[self.savedAtIndexInput_TF text] intValue]];
}

- (void) onSavedFpImagesCleared:(int) savedAtIndex;
{
    _userInstruction.text = @"";
    if(savedAtIndex == -1)
        _commandResponse.text = @"All saved fingerprint images have been cleared from the IdentiFI memory.";
    else
        _commandResponse.text = [NSString stringWithFormat:(@"Fingerprint image saved at index %d has been cleared from the IdentiFI memory."),savedAtIndex] ;
}

//Handle modal segues
- (BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender;
{
    if( [identifier isEqualToString:@"ShowLEDControl"] )
        return true;
    else if ([identifier isEqualToString:@"ShowLEDBrightness"] )
        return false;
    else if ([identifier isEqualToString:@"ShowPowerOffMode"] )
        return false;
    else if ([identifier isEqualToString:@"ShowSuspendMode"] )
        return false;

    return false;
    
    //return true;
}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    ViewController *destinationVC = segue.destinationViewController;
    if ([segue.identifier isEqualToString:@"ShowLEDControl"] )
    {
        destinationVC.Power_LED = self.Power_LED;
        destinationVC.Fp_LED = self.Fp_LED;
        destinationVC.Com_LED = self.Com_LED;
        destinationVC.Iris_LED = self.Iris_LED;
        destinationVC.mSec_On = self.mSec_On;
        destinationVC.mSec_Off = self.mSec_Off;
        return;
    }

    if ([segue.identifier isEqualToString:@"ShowPowerOffMode"] )
    {
        destinationVC.secondsToPowerOff = self.secondsToPowerOff;
        return;
    }
    
    if ([segue.identifier isEqualToString:@"ShowLEDBrightness"] )
    {
        destinationVC.LED_Brightness = self.LED_Brightness;
        return;
    }

}

//LED control
-(IBAction) unwindSegueFromLEDControl:(UIStoryboardSegue *) unwindSegue
{
    [myIdentiFI_Device setLEDControlForPowerLED:self.Power_LED
                                          FpLED:self.Fp_LED
                                         ComLED:self.Com_LED
                                        IrisLED:self.Iris_LED
                                         mSecOn:self.mSec_On
                                        mSecOff:self.mSec_Off];
}

- (void) onSetLEDControlForPowerLED:(int) pwr FpLED:(int) fp ComLED:(int) com IrisLED:(int) iris mSecOn:(int) mOn mSecOff:(int) mOff
{
    self.Power_LED = pwr;
    self.Fp_LED = fp;
    self.Com_LED = com;
    self.Iris_LED = iris;
    self.mSec_On = mOn;
    self.mSec_Off = mOff;
}

//LED Brightness
- (IBAction) setLEDBrightness:(id)sender
{
    _commandResponse.text = @"Getting LED brightness";
    [myIdentiFI_Device getLEDBrightness];
}

- (IBAction)setRedearPowerOffMode:(id)sender {
    
    _commandResponse.text = @"Getting reader power off mode.";
    [myIdentiFI_Device getPowerOffMode];
    
}

- (void) onGetLEDBrightness:(int) ledBrightness;
{
    self.LED_Brightness = ledBrightness;
    [self performSegueWithIdentifier:@"ShowLEDBrightness" sender:self];
}

-(IBAction) unwindSegueFromLEDBrightness:(UIStoryboardSegue *) unwindSegue
{
    [myIdentiFI_Device setLEDBrightness:self.LED_Brightness];
}
- (void) onSetLEDBrightness:(int) ledBrightness
{
    _commandResponse.text = [NSString stringWithFormat:(@"LED brightness = %d"),ledBrightness] ;
}


-(void) onGetPowerOffMode:(int) seconds
{
    self.secondsToPowerOff = seconds;
    [self performSegueWithIdentifier:@"ShowPowerOffMode" sender:self];
}

-(IBAction) unwindSegueFromPowerOffdMode:(UIStoryboardSegue *) unwindSegue
{
    [myIdentiFI_Device  setPowerOffMode:self.secondsToPowerOff];
}

-(void) onSetReaderSuspendMode:(int) seconds
{

    if(seconds > 0)
        _commandResponse.text=[NSString stringWithFormat:(@"IdentiFI will suspend when it idle for %d seonds"),seconds] ;
    else
        _commandResponse.text=[NSString stringWithFormat:(@"IdentiFI's suspend mode disabled.")] ;
}

-(IBAction) startFirmwareUpdate:(id)sender {

    UIAlertController * confirmUpdateUIAlert=   [UIAlertController alertControllerWithTitle:@"Firmware Update"
                                                                     message:@"Update connected IdentiFI firmware?"
                                                              preferredStyle:UIAlertControllerStyleAlert];

    UIAlertAction* yesAction = [UIAlertAction actionWithTitle:@"Yes"
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction * action)
    {
        [confirmUpdateUIAlert dismissViewControllerAnimated:YES completion:nil];

//Uncomment this section and change the firmware file name accordingly to the file you received S.I.C. Biometrics.
//        NSString *filepath = [[NSBundle mainBundle] pathForResource:@"IdentiFI_v000x_Encrypted_With_key_YourCompanyName_SDK_2023-mm-dd" ofType:@"bin"];
//        NSURL *fileUrl = [NSURL fileURLWithPath:filepath];
//        NSData *fileData = [NSData dataWithContentsOfURL:fileUrl];
//        self->_commandResponse.text=@"IdentiFI firmware update started..." ;
//        [self->myIdentiFI_Device  startFirmwareUpdate:(NSData *)fileData];

    }];

    UIAlertAction*  noAction = [UIAlertAction actionWithTitle:@"No"
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction * action)
    {
        [confirmUpdateUIAlert dismissViewControllerAnimated:YES completion:nil];
    }];

    [confirmUpdateUIAlert addAction:yesAction];
    [confirmUpdateUIAlert addAction:noAction];

    [self presentViewController:confirmUpdateUIAlert animated:YES completion:nil];

}

- (void) onFirmwareTransferCompleted:(long) transferResult
{
    _commandResponse.text=[NSString stringWithFormat:(@"IdentiFI's firmware update returned with code: %ld"), transferResult];
}


@end
