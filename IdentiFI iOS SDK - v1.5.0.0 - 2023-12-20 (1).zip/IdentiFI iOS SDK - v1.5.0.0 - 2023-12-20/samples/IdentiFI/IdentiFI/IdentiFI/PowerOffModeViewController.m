//
//  PowerOffModeViewController.m
//  IdentiFI
//
//  Copyright © 2015 - 2023 S.I.C. Biometrics . All rights reserved.
//

#import "PowerOffModeViewController.h"
#import "ViewController.h"

@interface PowerOffModeViewController ()

@end

@implementation PowerOffModeViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.secondsToPowerOff_SL.value  =  self.secondsToPowerOff;
    self.secondsToPowerOff_TF.text = [NSString stringWithFormat:@"%d", (int) self.secondsToPowerOff_SL.value];
}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    ViewController *destinationVC = segue.destinationViewController;
    destinationVC.secondsToPowerOff = self.secondsToPowerOff_SL.value;
}


- (IBAction)secondsToPowerOff_SL:(id)sender
{
    self.secondsToPowerOff_TF.text = [NSString stringWithFormat:@"%d", (int) self.secondsToPowerOff_SL.value];
}
@end
