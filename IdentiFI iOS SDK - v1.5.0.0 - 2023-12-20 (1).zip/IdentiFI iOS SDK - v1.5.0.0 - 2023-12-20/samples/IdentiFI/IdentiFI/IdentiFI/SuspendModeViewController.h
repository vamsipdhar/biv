//
//  SuspendModeViewController.h
//  IdentiFI-DEV
//
//  Copyright © 2020 S.I.C. Biometrics . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SuspendModeViewController : UIViewController

@property int secondsToSuspend;

@property (strong, nonatomic) IBOutlet UITextField *secondsToSuspend_TF;

- (IBAction)secondsToSuspend_SL:(id)sender;
@property (strong, nonatomic) IBOutlet UISlider *secondsToSuspend_SL;

@end

