//
//  LEDBrightnessViewController.h
//  IdentiFI
//
//  Copyright © 2015 - 2023 S.I.C. Biometrics . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LEDBrightnessViewController : UIViewController

@property int LED_Brightness;

@property (strong, nonatomic) IBOutlet UITextField *ledBrightness_TF;

@property (strong, nonatomic) IBOutlet UISlider *ledBrightness_SL;
- (IBAction)ledBrightness_SL:(id)sender;

@end


