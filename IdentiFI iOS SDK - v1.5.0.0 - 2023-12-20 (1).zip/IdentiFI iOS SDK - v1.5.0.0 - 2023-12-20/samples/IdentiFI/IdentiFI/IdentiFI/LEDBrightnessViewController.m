//
//  LEDBrightnessViewController.m
//  IdentiFI
//
//  Copyright © 2015 - 2023 S.I.C. Biometrics . All rights reserved.
//

#import "LEDBrightnessViewController.h"
#import "ViewController.h"

@interface LEDBrightnessViewController ()

@end

@implementation LEDBrightnessViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.ledBrightness_SL.value  =  self.LED_Brightness;
    self.ledBrightness_TF.text = [NSString stringWithFormat:@"%d", (int) self.ledBrightness_SL.value];
}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    ViewController *destinationVC = segue.destinationViewController;
    destinationVC.LED_Brightness = self.ledBrightness_SL.value;
}

- (IBAction)ledBrightness_SL:(id)sender
{
    self.ledBrightness_TF.text = [NSString stringWithFormat:@"%d", (int) self.ledBrightness_SL.value];
}

@end
