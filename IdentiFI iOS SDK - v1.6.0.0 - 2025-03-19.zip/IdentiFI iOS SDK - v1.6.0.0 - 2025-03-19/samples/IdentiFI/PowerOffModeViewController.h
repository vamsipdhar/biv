//
//  PowerOffModeViewController.h
//  IdentiFI
//
//  Copyright © 2015 - 2025 S.I.C. Biometrics . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PowerOffModeViewController : UIViewController

@property int secondsToPowerOff;

@property (strong, nonatomic) IBOutlet UITextField *secondsToPowerOff_TF;

- (IBAction)secondsToPowerOff_SL:(id)sender;
@property (strong, nonatomic) IBOutlet UISlider *secondsToPowerOff_SL;

@end

