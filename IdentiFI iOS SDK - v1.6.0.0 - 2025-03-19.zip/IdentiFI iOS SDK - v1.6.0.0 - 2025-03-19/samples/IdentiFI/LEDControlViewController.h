//
//  LEDControlViewController.h
//  IdentiFI
//
//  Copyright © 2015 - 2025 S.I.C. Biometrics . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LEDControlViewController : UIViewController

@property  int Power_LED;
@property  int Fp_LED;
@property  int Com_LED;
@property  int Iris_LED;

@property  int mSec_On;
@property  int mSec_Off;

@property (strong, nonatomic) IBOutlet UISegmentedControl *PowerLED_SG;
- (IBAction)PowerLED_SG:(id)sender;

@property (strong, nonatomic) IBOutlet UISegmentedControl *FpLED_SG;
- (IBAction)FpLED_SG:(id)sender;

@property (strong, nonatomic) IBOutlet UISegmentedControl *ComLED_SG;
- (IBAction)ComLED_SG:(id)sender;

@property (strong, nonatomic) IBOutlet UISegmentedControl *IrisLED_SG;
- (IBAction)IrisLED_SG:(id)sender;


@property (strong, nonatomic) IBOutlet UISlider *mSecOn_SL;
- (IBAction)mSecOn_SL:(id)sender;
@property (strong, nonatomic) IBOutlet UITextField *mSecOn_TF;

@property (strong, nonatomic) IBOutlet UISlider *mSecOff_SL;
- (IBAction)mSecOff_SL:(id)sender;
@property (strong, nonatomic) IBOutlet UITextField *mSecOff_TF;

- (IBAction)clearAll:(id)sender;

@end


