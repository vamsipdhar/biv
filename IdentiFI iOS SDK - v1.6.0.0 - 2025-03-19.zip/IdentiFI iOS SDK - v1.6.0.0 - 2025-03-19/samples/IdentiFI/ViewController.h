//
//  ViewController.h
//  IdentiFI Sample
//
//  Copyright © 2015 - 2025 S.I.C. Biometrics . All rights reserved.
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "IdentiFI.h"

@interface ViewController : UIViewController
{
    IdentiFI *myIdentiFI_Device;

}


@property (strong, nonatomic) IBOutlet UIButton *connect;
@property (strong, nonatomic) IBOutlet UIButton *disconnect;
@property (strong, nonatomic) IBOutlet UIButton *getBatteryLevel;
@property (strong, nonatomic) IBOutlet UIButton *getDeviceSerialNumber;
@property (strong, nonatomic) IBOutlet UIButton *getFirmwareVersion;
@property (strong, nonatomic) IBOutlet UIButton *startFirmwareUpdate;


@property (strong, nonatomic) IBOutlet UIButton *getLibraryVersion;
@property (strong, nonatomic) IBOutlet UIButton *getModelNumber;
@property (strong, nonatomic) IBOutlet UIButton *getReaderDescription;
@property (strong, nonatomic) IBOutlet UIButton *setMinNFIQScore;
@property (strong, nonatomic) IBOutlet UIButton *startCaptureOneFinger;
@property (strong, nonatomic) IBOutlet UIButton *startCaptureTwoFinger;
@property (strong, nonatomic) IBOutlet UIButton *startCaptureFourFinger;
@property (strong, nonatomic) IBOutlet UIButton *startCaptureRollFinger;
@property (strong, nonatomic) IBOutlet UIButton *setFpPowerOn;
@property (strong, nonatomic) IBOutlet UIButton *setFpPowerOff;
@property (strong, nonatomic) IBOutlet UIButton *getFpPowerStatus;
@property (strong, nonatomic) IBOutlet UIButton *isFingerDuplicated;
@property (strong, nonatomic) IBOutlet UIButton *getSavedWSQFpImage;
@property (strong, nonatomic) IBOutlet UIButton *getSavedFpNFIQScore;
@property (strong, nonatomic) IBOutlet UIButton *getSavedSegmentedFpImage;
@property (strong, nonatomic) IBOutlet UIButton *clearSavedFpImages;
@property (strong, nonatomic) IBOutlet UIButton *setLEDBrightness;
@property (strong, nonatomic) IBOutlet UIButton *setLEDControl;

@property (strong, nonatomic) IBOutlet UIButton *getIrisPowerStatus;
@property (strong, nonatomic) IBOutlet UIButton *setIrisPowerOn;
@property (strong, nonatomic) IBOutlet UIButton *setIrisPowerOff;
@property (strong, nonatomic) IBOutlet UIButton *startCaptureIris;

@property (weak, nonatomic) IBOutlet UIView *viewIrisImages;
@property (weak, nonatomic) IBOutlet UIImageView *leftUserIrisImage;
@property (weak, nonatomic) IBOutlet UIImageView *rightUserIrisImage;

- (IBAction)startFirmwareUpdate:(id)sender;

@property (strong, nonatomic) IBOutlet UILabel *linkStatus;
@property (strong, nonatomic) IBOutlet UILabel *commandResponse;
@property (strong, nonatomic) IBOutlet UILabel *userInstruction;
@property (strong, nonatomic) IBOutlet UIImageView *fpImage;
@property (strong, nonatomic) IBOutlet UIImageView *greenLED;
@property (strong, nonatomic) IBOutlet UITextField *savedAtIndexInput_TF;
@property (strong, nonatomic) IBOutlet UITextField *minimumNFIQScore_TF;
@property (strong, nonatomic) IBOutlet UITextField *securityLevel_TF;

@property  int secondsToPowerOff;

@property  int Power_LED;
@property  int Fp_LED;
@property  int Com_LED;
@property  int Iris_LED;
@property  int mSec_On;
@property  int mSec_Off;

@property  int LED_Brightness;



- (IBAction)connect:(id)sender;
- (IBAction)disconnect:(id)sender;

- (IBAction)getBatteryLevel:(id)sender;
- (IBAction)getDeviceSerialNumber:(id)sender;
- (IBAction)getFirmwareVersion:(id)sender;
- (IBAction)getLibraryVersion:(id)sender;
- (IBAction)getModelNumber:(id)sender;
- (IBAction)getReaderDescription:(id)sender;

- (IBAction)setMinNFIQScore:(id)sender;
- (IBAction)startCaptureOneFinger:(id)sender;
- (IBAction)startCaptureTwoFinger:(id)sender;
- (IBAction)startCaptureFourFinger:(id)sender;
- (IBAction)startCaptureRollFinger:(id)sender;
- (IBAction)cancelCapture:(id)sender;

- (IBAction)setFpPowerOn:(id)sender;
- (IBAction)setFpPowerOff:(id)sender;
- (IBAction)getFpPowerStatus:(id)sender;

- (IBAction)setIrisPowerOn:(id)sender;
- (IBAction)setIrisPowerOff:(id)sender;
- (IBAction)getIrisPowerStatus:(id)sender;

- (IBAction)steppersavedAtIndex:(UIStepper *)sender;
- (IBAction)isFingerDuplicated:(id)sender;
- (IBAction)getSavedWSQFpImage:(id)sender;
- (IBAction)getSavedFpNFIQScore:(id)sender;
- (IBAction)getSavedSegmentedFpImage:(id)sender;
- (IBAction)clearSavedFpImages:(id)sender;

- (IBAction)setRedearPowerOffMode:(id)sender;

- (IBAction)setLEDBrightness:(id)sender;

- (IBAction)startCaptureIris:(id)sender;


@end
