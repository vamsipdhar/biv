//
//  AppDelegate.h
//  IdentiFI Sample
//
//  Copyright © 2015 - 2025 S.I.C. Biometrics . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

