//
//  LEDControlViewController.m
//  IdentiFI
//
//  Copyright © 2015 - 2025 S.I.C. Biometrics . All rights reserved.
//

#import "LEDControlViewController.h"
#import "ViewController.h"

@interface LEDControlViewController ()

@end

@implementation LEDControlViewController

- (void)viewDidLoad
{

    [super viewDidLoad];

    self.PowerLED_SG.selectedSegmentIndex =  (long) self.Power_LED;
    self.FpLED_SG.selectedSegmentIndex =  (long) self.Fp_LED;
    self.ComLED_SG.selectedSegmentIndex =  (long) self.Com_LED;
    self.IrisLED_SG.selectedSegmentIndex =  (long) self.Iris_LED;
       

    self.mSecOn_SL.value  =  (float) self.mSec_On;
    self.mSecOn_TF.text = [NSString stringWithFormat:@"%d", (int) self.mSec_On];

    self.mSecOff_SL.value =  (float) self.mSec_Off;
    self.mSecOff_TF.text = [NSString stringWithFormat:@"%d", (int) self.mSec_Off];
}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    ViewController *destinationVC = segue.destinationViewController;
    destinationVC.Power_LED = self.Power_LED;
    destinationVC.Fp_LED = self.Fp_LED;
    destinationVC.Com_LED = self.Com_LED;
    destinationVC.Iris_LED = self.Iris_LED;
    
    destinationVC.mSec_On = self.mSec_On;
    destinationVC.mSec_Off = self.mSec_Off;
}

- (IBAction)PowerLED_SG:(id)sender
{

    self.Power_LED =  (int) self.PowerLED_SG.selectedSegmentIndex;

}

- (IBAction)FpLED_SG:(id)sender
{

    self.Fp_LED =  (int) self.FpLED_SG.selectedSegmentIndex;

}

- (IBAction)ComLED_SG:(id)sender
{

    self.Com_LED =  (int) self.ComLED_SG.selectedSegmentIndex;

}


- (IBAction)IrisLED_SG:(id)sender {
    
    self.Iris_LED =  (int) self.IrisLED_SG.selectedSegmentIndex;
    
}

- (IBAction)mSecOn_SL:(id)sender
{

    self.mSecOn_TF.text = [NSString stringWithFormat:@"%d", (int) self.mSecOn_SL.value];

    if((self.mSecOn_SL.value + self.mSecOff_SL.value) > 2000)
    {
        self.mSecOff_SL.value = 2000 - self.mSecOn_SL.value;
        self.mSecOff_TF.text = [NSString stringWithFormat:@"%d", (int) self.mSecOff_SL.value];
    }

    self.mSec_On =  self.mSecOn_SL.value;
    self.mSec_Off =  self.mSecOff_SL.value;

}



- (IBAction)mSecOff_SL:(id)sender
{

    self.mSecOff_TF.text = [NSString stringWithFormat:@"%d", (int) self.mSecOff_SL.value];

    if((self.mSecOn_SL.value + self.mSecOff_SL.value) > 2000)
    {
        self.mSecOn_SL.value = 2000 - self.mSecOff_SL.value;
        self.mSecOn_TF.text = [NSString stringWithFormat:@"%d", (int) self.mSecOn_SL.value];
    }

    self.mSec_On =  self.mSecOn_SL.value;
    self.mSec_Off =  self.mSecOff_SL.value;

}

- (IBAction)clearAll:(id)sender
{

    self.Power_LED  = 0;
    self.PowerLED_SG.selectedSegmentIndex =  (long) self.Power_LED;

    self.Fp_LED = 0;
    self.FpLED_SG.selectedSegmentIndex =  (long) self.Fp_LED;

    self.Com_LED = 0;
    self.ComLED_SG.selectedSegmentIndex =  (long) self.Com_LED;

    self.Iris_LED = 0;
    self.IrisLED_SG.selectedSegmentIndex = (long) self.Iris_LED;
    
    self.mSecOn_TF.text = @"0";
    self.mSec_On = 0;
    self.mSecOn_SL.value = 0;

    self.mSecOff_TF.text = @"0";
    self.mSec_Off = 0;
    self.mSecOff_SL.value = 0;

}

@end
