//
//  SuspendModeViewController.m
//  IdentiFI
//
//  Copyright © 2015 - 2025 S.I.C. Biometrics . All rights reserved.
//

#import "SuspendModeViewController.h"
#import "ViewController.h"

@interface SuspendModeViewController ()

@end

@implementation SuspendModeViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.secondsToSuspend_SL.value  =  self.secondsToSuspend;
    self.secondsToSuspend_TF.text = [NSString stringWithFormat:@"%d", (int) self.secondsToSuspend_SL.value];
}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    ViewController *destinationVC = segue.destinationViewController;
    destinationVC.secondsToSuspend = self.secondsToSuspend_SL.value;
}


- (IBAction)secondsToSuspend_SL:(id)sender
{
    self.secondsToSuspend_TF.text = [NSString stringWithFormat:@"%d", (int) self.secondsToSuspend_SL.value];
}
@end
