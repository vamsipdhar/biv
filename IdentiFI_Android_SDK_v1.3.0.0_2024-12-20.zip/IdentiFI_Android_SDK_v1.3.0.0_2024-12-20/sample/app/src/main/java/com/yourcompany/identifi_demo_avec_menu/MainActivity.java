package com.yourcompany.identifi_demo_avec_menu;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;

import com.sicbiometrics.identifi.scanner;
import com.sicbiometrics.identifi.scannerListener;

import java.nio.ByteBuffer;

public class MainActivity extends Activity implements scannerListener, PopupMenu.OnMenuItemClickListener, View.OnClickListener {
    private scanner IdentiFI = null;
    private TextView textLinkStatus = null;
    private TextView textResponse = null;
    private TextView textInstruction = null;
    private ImageView imageView1 = null;
    private ImageView imageView2 = null;
    private String strCaptureType = "";
    private ImageButton ib_menu;
    private Spinner ImageIndex;
    private boolean IsFpCapture = false;
    private int m_Seconds = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ib_menu = (ImageButton) findViewById(R.id.imageButtonMenu);
        ib_menu.setOnClickListener(MainActivity.this);

        try {
            IdentiFI = new scanner(this);
        } catch (Exception e) {
            e.printStackTrace();
        }

        textLinkStatus = (TextView) findViewById(R.id.Link_status);
        textInstruction = (TextView) findViewById(R.id.Instruction);
        textResponse = (TextView) findViewById(R.id.Response);

        imageView1 = (ImageView) findViewById(R.id.imageView1);
        imageView2 = (ImageView) findViewById(R.id.imageView2);
    }

    public void GetWSQEncodedFpImageFromImageSavedAtClick(View v) {
        //TODO: Implement code and spinner for Index selection.
    }

    @SuppressLint("SetTextI18n")
    public void CancelClick(View v) {

        textResponse.setText("Cancelling capture ...");
        textInstruction.setText("");

        if (IsFpCapture) {
            IdentiFI.CancelFpCapture();
        } else {
            IdentiFI.CancelIrisCapture();
        }
    }

    public void GetFirmwareVersionClick(View v) {
        textResponse.setText("");

        IdentiFI.GetFirmwareVersion();
    }

    public void GetReaderDescriptionClick(View v) {
        textResponse.setText("");
        IdentiFI.GetReaderDescription();
    }

    public void GetModelNumberClick(View v) {
        textResponse.setText("");
        IdentiFI.GetModelNumber();
    }

    public void GetBatteryPercentageClick(View v) {
        textResponse.setText("");
        IdentiFI.GetBatteryPercentage();
    }

    public void GetDeviceSerialNumberClick(View v) {
        textResponse.setText("");
        IdentiFI.GetDeviceSerialNumber();
    }

    public void GetFpPowerStatusClick(View v) {
        textResponse.setText("Getting Fp Power Status ...");
        IdentiFI.GetFpPowerStatus();
    }

    public void SetFpPowerOffClick(View v) {
        textResponse.setText("Powering OFF fingerprint sensor...");
        IdentiFI.SetFpPowerOff();
    }

    public void SetFpPowerOnClick(View v) {
        textResponse.setText("Setting fingerprint sensor port to On ...");
        IdentiFI.SetFpPowerOn();
    }

    public void GetSegmentedFpImageClick(View v) {
//        Spinner ImageIndex = (Spinner)  findViewById(com.sicbiometrics.identifi45.R.id.spinner1);
//        textResponse.setText("Retrieving Segmented fp image saved at index:" + String.valueOf(ImageIndex.getSelectedItem())) ;
//        capture.GetSegmentedFpImageSavedAt( (byte) Integer.parseInt(ImageIndex.getSelectedItem().toString()));
    }

    public void GetNfiqScoreClick(View v) {
//        Spinner ImageIndex = (Spinner)  findViewById(com.sicbiometrics.identifi45.R.id.spinner1);
//        textResponse.setText("Retrieving NFIQ score from fp image saved at index:" + String.valueOf(ImageIndex.getSelectedItem()));
//        capture.GetNfiqScoreFromImageSavedAt( (byte) Integer.parseInt(ImageIndex.getSelectedItem().toString()));
    }

    public void showMenu(View v) {
        PopupMenu popup = new PopupMenu(this, v);
        popup.setOnMenuItemClickListener(MainActivity.this);// to implement on click event on items of menu
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.main, popup.getMenu());
        popup.show();
    }

    @Override
    public void onSetPowerOffMode(int PowerOffModeSeconds) {
        textResponse.setText("onSetPowerOffMode:" + PowerOffModeSeconds + " second(s).");
    }

    @Override
    public void onGetPowerOffMode(int PowerOffModeSeconds) {
        textResponse.setText("onGetPowerOffMode:" + PowerOffModeSeconds + " second(s).");
    }

    @Override
    public void onStreaming(Bitmap bm) {
        imageView1.setImageBitmap(bm);
        if (imageView2.getVisibility() == View.VISIBLE)
            imageView2.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onStreamingIris(Bitmap LeftIrisBm, Bitmap RightIrisBm) {
        if (imageView2.getVisibility() == View.INVISIBLE)
            imageView2.setVisibility(View.VISIBLE);
        imageView1.setImageBitmap(LeftIrisBm);
        imageView2.setImageBitmap(RightIrisBm);
    }

    @Override
    public void onLastFrameIris(Bitmap LeftIrisBm, Bitmap RightIrisBm, int LeftIrisTotalScore, int LeftIrisUsableArea, int RightIrisTotalScore, int RightIrisUsableArea) {
        imageView1.setImageBitmap(LeftIrisBm);
        imageView2.setImageBitmap(RightIrisBm);
        textResponse.setText("Capture Results: LTS:" + LeftIrisTotalScore + ",LUA:" + LeftIrisUsableArea + ",RTS:" + RightIrisTotalScore + ",RUA:" + RightIrisUsableArea + ".");
        textInstruction.setText("Iris Capture Completed.");
    }

    @Override
    public void onFpCaptureStatus(int FpCaptureStatus) {
        switch (FpCaptureStatus) {
            case 1:
                textInstruction.setText("Finger capture didn't meet minimum NFIQ score.");
                break;
            case 9:
                textInstruction.setText("Failed to start FP capture, FP sensor not powered.");
                break;
            case 304:
                textInstruction.setText("Rolling smear detected.");
                break;
            case 305:
                textInstruction.setText("Rolled finger was shifted horizontally.");
                break;
            case 306:
                textInstruction.setText("Rolled finger was shifted vertically.");
                break;
            case 307:
                textInstruction.setText("Rolled finger was shifted both horizontally and vertically.");
                break;
            case -600:
                textInstruction.setText("Failed to extract details for duplicate.");
            default:
                textInstruction.setText("Unknown status/error code: " + FpCaptureStatus);
                break;
        }
    }

    @Override
    public void onIrisCaptureStatus(int IrisCaptureStatus) {
        switch (IrisCaptureStatus) {
            case 1:
                textInstruction.setText("Capture will begin...");
                break;
            case 2:
                textInstruction.setText("Eyes are detected! Keep moving.");
                break;
            case 3:
                textInstruction.setText("Capture completed.");
                break;
            case 5:
                textInstruction.setText("Capture Aborted error, Iris sensor capture stopped and powered off.");
                break;
            case 9:
                textInstruction.setText("Failed to start Iris capture, Iris sensor not powered.");
                break;
            default:
                textInstruction.setText("Unknown status/error code: " + IrisCaptureStatus);
                break;
        }
    }

    @Override
    public void onGetWSQEncodedFpImage(byte[] wsqImage, int SavedIndex) {
        textResponse.setText("Received " + wsqImage.length + " bytes from WSQ image saved in IdentiFI-45 at index: " + SavedIndex);
    }

    @Override
    public void onConnection() {
        textLinkStatus.setText("Connected");
    }

    @Override
    public void onConnectionTimeOut() {
        textLinkStatus.setText("Connection timed out.");
    }

    @Override
    public void onDisconnection() {
        textLinkStatus.setText("Disconnected");
    }

    @Override
    public void onGetFirmwareVersion(String version) {
        textResponse.setText("Firmware Version " + version);
    }

    @Override
    public void onGetReaderDescription(String ReaderDescription) {
        textResponse.setText("Reader Description: " + ReaderDescription);
    }

    @Override
    public void onGetBatteryPercentage(int level) {
        textResponse.setText(String.format("Battery: %d %%", level));
    }

    @Override
    public void onGetDeviceSerialNumber(String serial) {
        textResponse.setText("S/N: " + serial);
    }

    @Override
    public void onGetModelNumber(String model) {
        textResponse.setText("Model: " + model);
    }

    @Override
    public void onSetFpPowerOff() {
        textResponse.setText("Set fingerprint sensor power to Off.");
    }

    @Override
    public void onSetIrisPowerOff() {
        textResponse.setText("Set iris sensor power to Off.");
    }

    @Override
    public void onSavedFpImagesCleared() {
        textResponse.setText("All saved fingerprint images have been cleared from the IdentiFI-45 memory.");
    }

    @Override
    public void onSetFpPowerOn(int FpPowerStatus) {
        if (FpPowerStatus == 1)
            textResponse.setText("Set fingerprint sensor power to On succeeded.");
        else
            textResponse.setText("Failed to power and wake up FP sensor.");
    }

    @Override
    public void onSetIrisPowerOn(int IrisPowerStatus) {
        if (IrisPowerStatus == 1)
            textResponse.setText("Set iris sensor power to On succeeded.");
        else
            textResponse.setText("Failed to power and wake up iris sensor.");
    }

    @Override
    public void onGetFpPowerStatus(int FpPowerStatus) {
        if (FpPowerStatus == 1)
            textResponse.setText("Fingerprint sensor power is On.");
        else
            textResponse.setText("Fingerprint sensor power is Off.");

    }

    @Override
    public void onGetIrisPowerStatus(int IrisPowerStatus) {
        if (IrisPowerStatus == 1)
            textResponse.setText("Iris sensor power is On.");
        else
            textResponse.setText("Iris sensor power is Off.");

    }

    @Override
    public void onCancelFpCapture() {
        textResponse.setText("Fp Capture cancel by user.");
    }

    @Override
    public void onCancelIrisCapture() {
        textResponse.setText("Iris Capture cancel by user.");
    }

    @Override
    public void onStreamingRolledFp(Bitmap bm, int currentRollingState, int currentXPosition) {
        if (imageView2.getVisibility() == View.VISIBLE)
            imageView2.setVisibility(View.INVISIBLE);

        Canvas canvas = new Canvas(bm);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        switch (currentRollingState) {
            case 0: //FINGER NOT YET DETECTED
                break;
            case 1: //BEGIN ROLLING
                paint.setColor(Color.RED);
                canvas.drawLine(currentXPosition, 0, currentXPosition, bm.getHeight(), paint);
                break;
            case 2: //KEEP ROLLING
                paint.setColor(Color.GREEN);
                canvas.drawLine(currentXPosition, 0, currentXPosition, bm.getHeight(), paint);
                break;
            default: //Should not get here.
                break;
        }
        imageView1.setImageBitmap(bm);
    }

    @Override
    public void onLastFrame(Bitmap bm, int SavedIndex) {
        textResponse.setText(strCaptureType + " capture completed. RAW fp image saved in IdentiFI-45 at index: " + SavedIndex);
        textInstruction.setText("");
        imageView1.setImageBitmap(bm);
    }

    @Override
    public void onLastFrame_RAW(byte[] RAWImage, int SavedIndex) {
        //textResponse.setText(strCaptureType + " capture completed. RAW fp image saved in IdentiFI-45 at index: " +  SavedIndex);
        //textInstruction.setText("");
    }

    @Override
    public void onGetNfiqScore(int NFIQ_Score, int ImageIndex) {
        textResponse.setText("NFIQ Score:" + NFIQ_Score + " for image saved at index " + ImageIndex);
    }

    @Override
    public void onGetSegmentedFpImage_RAW(byte[] RAWImage, int SavedIndex) {
        if (RAWImage.length == 600000) {
            textResponse.setText("Received " + RAWImage.length + " bytes from RAW fp image saved in IdentiFI-45 at index: " + SavedIndex);
            byte[] bits = new byte[RAWImage.length * 4]; //That's where the RGBA array goes.
            int i;
            for (i = 0; i < RAWImage.length; i++) {
                bits[i * 4] = bits[i * 4 + 1] = bits[i * 4 + 2] = (byte) RAWImage[i]; //Invert the source bits
                bits[i * 4 + 3] = (byte) 0xff; // the alpha.
            }
            Bitmap bm = Bitmap.createBitmap(800, 750, Bitmap.Config.ARGB_8888);
            bm.copyPixelsFromBuffer(ByteBuffer.wrap(bits));

            Bitmap bOutput;
            Matrix matrix = new Matrix();
            matrix.preScale(1.0f, -1.0f);
            bOutput = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), matrix, true);

            imageView1.setImageBitmap(bOutput);

        } else {
            textResponse.setText("No RAW fp image saved in IdentiFI-45 at index: " + SavedIndex);
            imageView1.setImageResource(0);
        }
    }

    @Override
    public void onLastFrameRolledFp(Bitmap bm, int SavedIndex) {
        textResponse.setText(strCaptureType + " capture completed. RAW fp image saved in IdentiFI-45 at index: " + SavedIndex);
        textInstruction.setText("");
        imageView1.setImageBitmap(bm);
    }

    @Override
    public void onLastFrameRolledFp_RAW(byte[] RAWImage, int SavedIndex) {
        //textResponse.setText(strCaptureType + " capture completed. \nrawFpImage saved in IdentiFI-45 at index: " +  SavedIndex);
        //textInstruction.setText("");
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {

        textResponse.setText("");
        textInstruction.setText("");
        imageView1.setImageResource(0);
        imageView2.setImageResource(0);

        switch (item.getItemId()) {
            case R.id.connect:
                textLinkStatus.setText("Connecting ...");
                IdentiFI.Connect();
                return true;

            case R.id.disconnect:
                textLinkStatus.setText("Disconnecting ...");
                IdentiFI.Disconnect();
                return true;

            case R.id.device_sn:
                IdentiFI.GetDeviceSerialNumber();
                return true;

            case R.id.segmented_image:
//                Spinner ImageIndex = (Spinner)  findViewById(com.sicbiometrics.identifi45.R.id.spinner1);
//                textResponse.setText("Retrieving Segmented fp image saved at index:" + String.valueOf(ImageIndex.getSelectedItem())) ;
//                capture.GetSegmentedFpImageSavedAt( (byte) Integer.parseInt(ImageIndex.getSelectedItem().toString()));
                return true;

            case R.id.battery_percentage:
                IdentiFI.GetBatteryPercentage();
                return true;

            case R.id.library_version:
                textResponse.setText("Library " + IdentiFI.GetLibraryVersion());
                return true;

            case R.id.model_number:
                IdentiFI.GetModelNumber();
                return true;

            case R.id.reader_description:
                IdentiFI.GetReaderDescription();
                return true;

            case R.id.firmware_version:
                IdentiFI.GetFirmwareVersion();
                return true;

            case R.id.fp_power_on:
                textResponse.setText("Setting fingerprint sensor port to On ...");
                IdentiFI.SetFpPowerOn();
                return true;

            case R.id.fp_power_off:
                textResponse.setText("Powering OFF fingerprint sensor...");
                IdentiFI.SetFpPowerOff();
                return true;

            case R.id.fp_power_status:
                textResponse.setText("Getting Fp Power Status ...");
                IdentiFI.GetFpPowerStatus();
                return true;

            case R.id.clear_fp_image:
                textResponse.setText("Clearing saved fp images from IdentiFI-45.");
                IdentiFI.ClearSavedFpImage();
                return true;

            case R.id.wsq_image:
//                ImageIndex = (Spinner)  findViewById(com.sicbiometrics.identifi45.R.id.spinner1);
//                textResponse.setText("Retrieving WSQ fp image saved at index:" + String.valueOf(ImageIndex.getSelectedItem())) ;
//                capture.GetWSQEncodedFpImageFromImageSavedAt( (byte) Integer.parseInt(ImageIndex.getSelectedItem().toString()));
                return true;

            case R.id.single_finger:
                strCaptureType = "Single Finger Capture:";
                textInstruction.setText("Place one finger on the sensor ");
                IsFpCapture = true;
                IdentiFI.StartCaptureOneFinger();
                return true;

            case R.id.two_finger:
                strCaptureType = "Two Finger Capture:";
                textInstruction.setText("Place two finger on the sensor");
                IsFpCapture = true;
                IdentiFI.StartCaptureTwoFinger();
                return true;

            case R.id.roll_finger:
                strCaptureType = "Roll Finger Capture:";
                textInstruction.setText("Place one finger on the sensor and then start rolling");
                IsFpCapture = true;
                IdentiFI.StartCaptureRollFinger();
                return true;

            case R.id.nfiq_score:
//                ImageIndex = (Spinner)  findViewById(com.sicbiometrics.identifi45.R.id.spinner1);
//                textResponse.setText("Retrieving NFIQ score from fp image saved at index:" + String.valueOf(ImageIndex.getSelectedItem()));
//                capture.GetNfiqScoreFromImageSavedAt( (byte) Integer.parseInt(ImageIndex.getSelectedItem().toString()));
                return true;

            case R.id.iris_power_on:
                textResponse.setText("Setting iris sensor port to On ...");
                IdentiFI.SetIrisPowerOn();
                return true;

            case R.id.iris_power_off:
                textResponse.setText("Powering off iris sensor...");
                IdentiFI.SetIrisPowerOff();
                return true;

            case R.id.iris_power_status:
                textResponse.setText("Getting iris Power Status ...");
                IdentiFI.GetIrisPowerStatus();
                return true;

            case R.id.capture_iris:
                strCaptureType = "Capture Iris:";
                textInstruction.setText("Iris capture started ");
                IsFpCapture = false;
                IdentiFI.StartCaptureIris();
                return true;

            case R.id.set_poweroff_mode:

                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Power Off mode");
                builder.setMessage("Enter the number of seconds (>=60 sec) before the unit powers off when not being used. Enter 0 to disable the PowerOff mode.");

                final EditText input = new EditText(this);
                builder.setView(input);
                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int button) {
                        m_Seconds = Integer.parseInt(String.valueOf("0" + input.getText()));
                        textInstruction.setText("Setting PowerOff mode to " + m_Seconds + " second(s).");
                        IdentiFI.SetPowerOffMode(m_Seconds);
                    }
                });

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int button) {
                    }
                });

                builder.show();

                return true;

            case R.id.get_poweroff_mode:
                textInstruction.setText("Getting PowerOff mode");
                IdentiFI.GetPowerOffMode();
                return true;

            default:
                return false;
        }
    }

    @Override
    public void onClick(View view) {
        if (view == ib_menu) {
            showMenu(view);
        }
    }

}
